function [xi,k] = Chiadoi_app(f, a, b, eps)
    fx = str2func(['@(x)',f]);
    % Ham tim nghiem
    k=0;
    xn = zeros(1,50);
    for i=1:50
        xn(i) = (a+b)/2;
        if fx(a)*fx(xn(i))>0 % f(a) va f(x) trai dau
            a = xn(i);
        else
            b = xn(i);
        end
        if abs(b-a) <eps
            break;
        end
        k = k+1;
    end
    xi = xn(k+1);
end