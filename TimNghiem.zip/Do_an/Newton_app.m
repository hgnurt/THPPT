function [xi,k] = Newton_app(fx,a,b,eps)
    % Ham tim nghiem
    syms 'x';
    g = matlabFunction(diff(fx,x));
    h = matlabFunction(diff(g,x));
    y = fx(a)*h(a);
    if y>0
        x0 = a;
    else
        x0 = b;
    end
    k=0;
    xn = zeros(1,50);
    xn(1) = x0 - fx(x0)/g(x0);
    for i=1:50
        xn(i+1) = xn(i) - fx(xn(i))/g(xn(i));
        k = k+1;
        if abs(xn(i+1)-xn(i)) < eps
            break;
        end
    end
    xi = xn(k+1);
end