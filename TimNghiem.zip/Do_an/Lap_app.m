function [xi,k] = Lap_app(g,a,eps)
    k = 0;
    xn = zeros(1,50);
    xn(1) = a; %x0
    for i=2:50
        xn(i) = g(xn(i-1)) + xn(i-1);
        k = k+1;
        if abs(xn(i)-xn(i-1)) < eps
            break;
        end
    end
    xi = xn(k+1);
end